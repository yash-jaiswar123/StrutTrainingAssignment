package com.yash.technology.exception;

public class UsernameNotFoundException extends Exception {

	private String message;
	public UsernameNotFoundException(String msg) {
		this.message=msg;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
