package com.yash.technology.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.technology.model.User;

@Repository
public interface UserRepository {

	public List<User>getAllUsers();
	
}
