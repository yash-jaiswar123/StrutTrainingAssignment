package com.yash.technology.service;

import com.yash.technology.exception.UsernameNotFoundException;
import com.yash.technology.model.User;

public interface UserService {

	public User getUserWithMaxAge();
	
	public boolean isLoginValid(String name,String password) throws UsernameNotFoundException;
}
