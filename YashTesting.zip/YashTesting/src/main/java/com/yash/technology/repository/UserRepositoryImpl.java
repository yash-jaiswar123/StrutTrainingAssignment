package com.yash.technology.repository;

import java.util.Arrays;
import java.util.List;

import com.yash.technology.model.User;

public class UserRepositoryImpl implements UserRepository{

	@Override
	public List<User> getAllUsers() {
		User u1=new User(1,"amit",21,"Sales","123");
		User u2=new User(2,"neha",22,"marketing","123");
		User u3=new User(3,"vishal",23,"sales","dfsa");
		User u4=new User(4,"jatin",20,"Sales","abc");
		List<User>users=(List<User>)Arrays.asList(u1,u2,u3,u4);
		return users;
	}

	
}
 