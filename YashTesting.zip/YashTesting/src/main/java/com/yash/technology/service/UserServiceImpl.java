package com.yash.technology.service;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.technology.exception.UsernameNotFoundException;
import com.yash.technology.model.User;
import com.yash.technology.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repo;
	
	@Override
	public User getUserWithMaxAge() {
		return repo.getAllUsers().stream().sorted((u1,u2)->u2.getAge()-u1.getAge()).limit(1).collect(Collectors.toList()).get(0);
	
	}
	@Override
	public boolean isLoginValid(String name, String password) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		//users.stream().filter(e->(e.getName().equals(name) && e.getPassword().equals(password))).collect(Collectors.toList()).size()==1;
		if(repo.getAllUsers().stream().filter(e->e.getName().equals(name)).collect(Collectors.toList()).size()==0)
			throw new UsernameNotFoundException("username not exist");
			
		return repo.getAllUsers().stream().filter(e->(e.getName().equals(name) && e.getPassword().equals(password))).collect(Collectors.toList()).size()==1;
	}
	
}
