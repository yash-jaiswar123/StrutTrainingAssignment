package com.yash.technology.service;

public interface CalcService {

	public int addNumber(int a,int b);
	public int maxNumber(int a,int b);
}
