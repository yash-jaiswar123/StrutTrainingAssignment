package com.yash.technology.service;

import org.springframework.stereotype.Service;

@Service
public class CalcServiceImpl implements CalcService{

	@Override
	public int addNumber(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	
	public int maxNumber(int a,int b)
	{
	return a>b?a:b;
	}
}
