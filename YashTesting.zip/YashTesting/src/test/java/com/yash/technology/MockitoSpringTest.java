package com.yash.technology;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.technology.model.User;
import com.yash.technology.repository.UserRepository;
import com.yash.technology.service.UserServiceImpl;
import com.yash.technology.model.*;
import java.util.List;

@SpringBootTest
public class MockitoSpringTest {

	User u1=new User(1,"amit",21,"Sales","123");
	User u2=new User(2,"neha",22,"marketing","123");
	List<User> users=(List<User>)Arrays.asList(u1,u2);
	@Mock
	UserRepository userRepo;
	
	@InjectMocks
	UserServiceImpl service;
	
	@Test
	void testForGettingUserWithMaxAge()
	{
		
	//	when(userRepo.getAllUsers()).thenReturn(List<User>Arrays.asList(u1,u2));
		when(userRepo.getAllUsers()).thenReturn(users);
		assertEquals(service.getUserWithMaxAge().getName(), "neha");
	}
	
}
