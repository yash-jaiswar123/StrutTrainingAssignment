package com.yash.technology;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.technology.exception.UsernameNotFoundException;
import com.yash.technology.service.CalcService;
import com.yash.technology.service.UserService;
import com.yash.technology.service.UserServiceImpl;

@SpringBootTest
class YashTestingApplicationTests {

	@Autowired
	CalcService calc;
	
	@Autowired
	UserService uService;

	@Test
	void  testAddNumber()
	{
		assertEquals(calc.addNumber(2, 3),5);
		assertEquals(calc.maxNumber(3, 10),10);
		assertEquals("vishal",uService.getUserWithMaxAge().getName());
		
	}

	@Test
	void testUserNameNotExist()
	{
		
		try
		{
			assertTrue(uService.isLoginValid("amit","123"));
			assertTrue(!uService.isLoginValid("amit","12345"));
			UsernameNotFoundException excep=Assertions.assertThrows(UsernameNotFoundException.class,()->uService.isLoginValid("yash", "345"));
		}catch(Exception e)
		{
			
		}
		
	}
	
}
