package com.yash.technology.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.yash.technology.model.Car;

@Configuration
@ComponentScan(basePackages = "com.yash.technology.model")
public class SpringConfig {

	@Bean(name="Maruti")
	public Car getCar()
	{
			return new Car(1,"Ertiga","Maruti","XVLL");
	}
	
	@Bean(name="Honda")
	public Car getCar1()
	{
			return new Car(1,"City","Honda","XL");
	}
}
