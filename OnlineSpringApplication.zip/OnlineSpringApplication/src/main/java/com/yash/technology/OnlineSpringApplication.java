package com.yash.technology;




import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.technology.config.SpringConfig;
import com.yash.technology.model.Car;
import com.yash.technology.model.Employee;

@SpringBootApplication
public class OnlineSpringApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(OnlineSpringApplication.class, args);
		
		
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		ApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
	//	Car c1=context.getBean(Car.class);
	//	System.out.println(c1);
		
		Car c1=(Car)context.getBean("Maruti");
		System.out.println(c1);
		
		Car c2=(Car)context.getBean("Honda");
		System.out.println(c2);
		//if i do not use ComponentScan annotation
	//ApplicationContext context1=new AnnotationConfigApplicationContext("com.yash.technology.model");

		Employee e=context.getBean(Employee.class);
		System.out.println(e);
		e.getDog().bark();
		
		
		//Above task we can do with Car class also
	}

}
