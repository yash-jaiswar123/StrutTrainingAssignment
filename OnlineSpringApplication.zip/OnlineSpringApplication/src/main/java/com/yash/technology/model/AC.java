package com.yash.technology.model;

import org.springframework.stereotype.Component;

@Component
public class AC {

	private int id;
	private String model;
	
	
	
	@Override
	public String toString() {
		return "AC [id=" + id + ", model=" + model + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	
	
}
