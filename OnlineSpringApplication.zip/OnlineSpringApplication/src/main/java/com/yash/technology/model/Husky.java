package com.yash.technology.model;

import org.springframework.stereotype.Component;

import com.yash.technology.interfaces.Dog;

@Component("husky")
public class Husky implements Dog{

	@Override
	public void bark() {
		System.out.println("Loud voice");
	}

	
}
