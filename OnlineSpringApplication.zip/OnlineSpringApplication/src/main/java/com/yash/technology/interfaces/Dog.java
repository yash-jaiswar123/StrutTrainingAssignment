package com.yash.technology.interfaces;

public interface Dog {

	public void bark();
	
}
