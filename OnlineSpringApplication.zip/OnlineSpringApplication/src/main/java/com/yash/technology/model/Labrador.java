package com.yash.technology.model;

import org.springframework.stereotype.Component;

import com.yash.technology.interfaces.Dog;

@Component("labrador")
public class Labrador implements Dog {

	@Override
	public void bark() {
		// TODO Auto-generated method stub
		System.out.println("slow voice");
	}

	
}
