package com.yash.technology.dao;
import java.util.List;

import com.yash.technology.model.Employee;


public interface EmployeeDAOInterface {

	public List<Employee> getAllEmployees() throws Exception;
	public Employee getEmployeeById(int eid);
	public void addEmployee(Employee user);
	public void deleteById(int eid);
	public void updateEmployee(Employee user);
	
	public List<Employee> getByDepartment(String department);
}
