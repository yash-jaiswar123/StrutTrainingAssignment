package com.yash.technology.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.technology.dao.EmployeeDAO;
import com.yash.technology.model.UpdateOrDelete;

public class DeleteAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		UpdateOrDelete ud=(UpdateOrDelete)form;
		new EmployeeDAO().deleteById(ud.getEid());
		request.setAttribute("employees", new EmployeeDAO().getAllEmployees());
		return mapping.findForward("success");
	}

	
}
