package com.yash.technology.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.technology.dao.DepartmentDAOImpl;
import com.yash.technology.model.Employee;

public class EmployeeAdd extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setAttribute("departments",new DepartmentDAOImpl().getAllDepartment());
		
		return mapping.findForward("success");
	}

	
	
}
