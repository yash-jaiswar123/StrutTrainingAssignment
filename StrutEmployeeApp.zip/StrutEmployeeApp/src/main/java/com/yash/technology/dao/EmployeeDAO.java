package com.yash.technology.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;



import com.yash.technology.model.Employee;
//ublic Employee(int eid, String ename, String designation, int salary, String email) 
import com.yash.technology.model.EmployeeWithDepartment;
public class EmployeeDAO implements EmployeeDAOInterface {

	@Override
	public List<Employee> getAllEmployees() throws Exception{
		Connection c=DAOConnection.getConnection();
		Statement s=c.createStatement();
		List<Employee> lst=new ArrayList<Employee>();
		
		ResultSet rs=s.executeQuery("select * from employee");
		while(rs.next())
		{
			lst.add(new Employee(rs.getInt("eid"),rs.getString("ename"),rs.getString("designation"),rs.getInt("salary"),rs.getString("email"),0,0));
		}
		
		return lst;
	}

	@Override
	public Employee getEmployeeById(int eid) {
		Employee u=null;
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select * from employee where eid=?");
			ps.setInt(1, eid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
		//ublic Employee(int eid, String ename, String designation, int salary, String email) 
				u=new Employee(rs.getInt("eid"),rs.getString("ename"),rs.getString("designation"),rs.getInt("salary"),rs.getString("email"),0,0);
			}
			System.out.println(u);
		}catch(Exception e)
		{
			
			System.out.println(e);
		}
		return u;
	}

	@Override
	public void addEmployee(Employee user) {
		try
		{
		Connection c=DAOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into employee(eid,ename,salary,designation,email) values(?,?,?,?,?)");
		ps.setInt(1, user.getEid());
		ps.setString(2, user.getEname());
		ps.setInt(3, user.getSalary());
		ps.setString(4,user.getDesignation());
		ps.setString(5, user.getEmail());
		ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void deleteById(int eid) {
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("delete from employee where eid=?");
			ps.setInt(1, eid);
			ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void updateEmployee(Employee user) {
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("update employee set ename=?,designation=?,salary=?,email=? where eid=?");
			ps.setString(1, user.getEname());
			ps.setString(2, user.getDesignation());
			ps.setInt(3, user.getSalary());
			ps.setString(4, user.getEmail());
			ps.setInt(5, user.getEid());
			ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public List<Employee> getByDepartment(String department) {
		List<Employee> employees=null;
		try
		{
			Connection c=DAOConnection.getConnection();
			String query="select e.eid,e.ename,e.salary from employee e where e.deptid=(select d1.deptid from department d1 where d1.dname='"+department+"')";
			System.out.println(query);
//			PreparedStatement ps=c.prepareStatement("select e.eid,e.ename,e.salary from employee e where e.deptid=(select d1.deptid from department d1 where d1.dname=?)");
//			ps.setString(1,department);
			PreparedStatement ps=c.prepareStatement(query);
			employees=new LinkedList<Employee>();
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				//int eid, String ename, String designation, int salary, String email
				employees.add(new Employee(rs.getInt("eid"),rs.getString("ename"),null,rs.getInt("salary"),null,0,0));
				System.out.println(rs.getInt("eid")+" "+rs.getString("ename"));
				
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return employees;
	}

	public List<EmployeeWithDepartment> getAllEmpDepartmentWise()
	{
		List<EmployeeWithDepartment> ewd=new LinkedList<EmployeeWithDepartment>();
		try
		{
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select eid,ename,dname,department.deptid,designation from employee,department where employee.deptid=department.deptid");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				//String ename, String dname, int deptid, String designation
				ewd.add(new EmployeeWithDepartment(rs.getInt("eid"),rs.getString("ename"),rs.getString("dname"),rs.getInt("deptid"),rs.getString("designation")));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return ewd;
	}
	
}
