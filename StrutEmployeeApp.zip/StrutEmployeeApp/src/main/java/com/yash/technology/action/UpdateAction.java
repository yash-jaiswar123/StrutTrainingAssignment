package com.yash.technology.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.technology.dao.DepartmentDAOImpl;
import com.yash.technology.dao.EmployeeDAO;
import com.yash.technology.model.Employee;
import com.yash.technology.model.UpdateOrDelete;

public class UpdateAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		UpdateOrDelete ud=(UpdateOrDelete)form;
		Employee e=new EmployeeDAO().getEmployeeById(ud.getEid());
		request.setAttribute("employee",e);
		request.setAttribute("departments", new DepartmentDAOImpl().getAllDepartment());
		request.setAttribute("managers",null);
		return mapping.findForward("success");
	}

	
	
}
