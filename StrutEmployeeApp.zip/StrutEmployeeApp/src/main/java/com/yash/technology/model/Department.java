package com.yash.technology.model;

public class Department {

	private int deptid;
	private String city;
	private String dname;
	
	
	public Department(int deptid, String city, String dname) {
		super();
		this.deptid = deptid;
		this.city = city;
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "Department [deptid=" + deptid + ", city=" + city + ", dname=" + dname + "]";
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	
	
	
}
