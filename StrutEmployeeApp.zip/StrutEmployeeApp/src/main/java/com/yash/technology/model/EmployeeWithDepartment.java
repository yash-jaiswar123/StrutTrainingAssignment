package com.yash.technology.model;

import org.apache.struts.action.ActionForm;

public class EmployeeWithDepartment extends ActionForm{

	private int eid;
	private String ename;
	private String dname;
	private int deptid;
	private String designation;
	
	
	
	
	public EmployeeWithDepartment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeWithDepartment(int eid,String ename, String dname, int deptid, String designation) {
		super();
		this.eid=eid;
		this.ename = ename;
		this.dname = dname;
		this.deptid = deptid;
		this.designation = designation;
	}
	
	
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	
	
	
}
