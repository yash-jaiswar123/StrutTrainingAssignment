package com.yash.technology.model;

import org.apache.struts.action.ActionForm;

public class UpdateOrDelete extends ActionForm{

	private int eid;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public UpdateOrDelete() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UpdateOrDelete(int eid) {
		super();
		this.eid = eid;
	}
	
	
	
}
