package com.yash.technology.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.technology.dao.EmployeeDAO;
import com.yash.technology.model.EmployeeWithDepartment;

public class DisplayByDepartment extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		List<EmployeeWithDepartment> ewd=new EmployeeDAO().getAllEmpDepartmentWise();
		
		request.setAttribute("ewd", ewd);
		
		return mapping.findForward("success");
	}

	
	
}
