package com.yash.model;

public class Department {

	
	public String deptName;
	public int id;
	
	public String city;
	
	
	public Department(String deptName, int id, String city) {
		super();
		this.deptName = deptName;
		this.id = id;
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Department [deptName=" + deptName + ", id=" + id + ", city=" + city + "]";
	}
	
}
