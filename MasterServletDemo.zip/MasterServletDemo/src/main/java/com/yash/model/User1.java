package com.yash.model;

public class User1 {

	private int eid;
	private String ename;
	private String designation;
	private int salary;
	private String email;
	public int getEid() {
		return eid;
	}
	
	
	
	public User1(int eid, String ename, String designation, int salary, String email) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.designation = designation;
		this.salary = salary;
		this.email = email;
	}



	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "User1 [eid=" + eid + ", ename=" + ename + ", designation=" + designation + ", salary=" + salary
				+ ", email=" + email + "]";
	}
	
	
	
}
