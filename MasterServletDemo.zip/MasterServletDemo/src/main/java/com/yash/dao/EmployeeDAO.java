package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


import com.yash.model.User1;
//ublic User1(int eid, String ename, String designation, int salary, String email) 
public class EmployeeDAO implements EmployeeDAOInterface {

	@Override
	public List<User1> getAllEmployees() throws Exception{
		Connection c=DAOConnection.getConnection();
		Statement s=c.createStatement();
		List<User1> lst=new ArrayList<User1>();
		
		ResultSet rs=s.executeQuery("select * from employee");
		while(rs.next())
		{
			lst.add(new User1(rs.getInt("eid"),rs.getString("ename"),rs.getString("designation"),rs.getInt("salary"),rs.getString("email")));
		}
		
		return lst;
	}

	@Override
	public User1 getEmployeeById(int eid) {
		User1 u=null;
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select * from employee where eid=?");
			ps.setInt(1, eid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
		//ublic User1(int eid, String ename, String designation, int salary, String email) 
				u=new User1(rs.getInt("eid"),rs.getString("ename"),rs.getString("designation"),rs.getInt("salary"),rs.getString("email"));
			}
			System.out.println(u);
		}catch(Exception e)
		{
			
			System.out.println(e);
		}
		return u;
	}

	@Override
	public void addEmployee(User1 user) {
		try
		{
		Connection c=DAOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into employee(eid,ename,salary,designation,email) values(?,?,?,?,?)");
		ps.setInt(1, user.getEid());
		ps.setString(2, user.getEname());
		ps.setInt(3, user.getSalary());
		ps.setString(4,user.getDesignation());
		ps.setString(5, user.getEmail());
		ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void deleteById(int eid) {
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("delete from employee where eid=?");
			ps.setInt(1, eid);
			ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void updateEmployee(User1 user) {
		try {
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("update employee set ename=?,designation=?,salary=?,email=? where eid=?");
			ps.setString(1, user.getEname());
			ps.setString(2, user.getDesignation());
			ps.setInt(3, user.getSalary());
			ps.setString(4, user.getEmail());
			ps.setInt(5, user.getEid());
			ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public List<User1> getByDepartment(String department) {
		List<User1> employees=null;
		try
		{
			Connection c=DAOConnection.getConnection();
			String query="select e.eid,e.ename,e.salary from employee e where e.deptid=(select d1.deptid from department d1 where d1.dname='"+department+"')";
			System.out.println(query);
//			PreparedStatement ps=c.prepareStatement("select e.eid,e.ename,e.salary from employee e where e.deptid=(select d1.deptid from department d1 where d1.dname=?)");
//			ps.setString(1,department);
			PreparedStatement ps=c.prepareStatement(query);
			employees=new LinkedList<User1>();
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				//int eid, String ename, String designation, int salary, String email
				employees.add(new User1(rs.getInt("eid"),rs.getString("ename"),null,rs.getInt("salary"),null));
				System.out.println(rs.getInt("eid")+" "+rs.getString("ename"));
				
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return employees;
	}

}
