package com.yash.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAOConnection {

	public static Connection getConnection() throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/springdata","root","root");
		return c;
	}
	
}
