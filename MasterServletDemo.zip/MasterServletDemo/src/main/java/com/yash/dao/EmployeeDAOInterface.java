package com.yash.dao;
import java.util.List;

import com.yash.model.*;
public interface EmployeeDAOInterface {

	public List<User1> getAllEmployees() throws Exception;
	public User1 getEmployeeById(int eid);
	public void addEmployee(User1 user);
	public void deleteById(int eid);
	public void updateEmployee(User1 user);
	
	public List<User1> getByDepartment(String department);
}
