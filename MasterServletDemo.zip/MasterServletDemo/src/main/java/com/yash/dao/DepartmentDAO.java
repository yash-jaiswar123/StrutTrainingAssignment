package com.yash.dao;

import java.util.List;

import com.yash.model.Department;

public interface DepartmentDAO {

	public void AddDepartment(Department department);
	public List<Department> getAllDepartment();
	public Department getById(int id);
	public void updateDepartment(Department dept);
	
}
