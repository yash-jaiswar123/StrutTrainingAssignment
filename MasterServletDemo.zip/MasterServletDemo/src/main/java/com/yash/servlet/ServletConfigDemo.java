package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletConfigDemo
 */
@WebServlet(value="/hello1",initParams = {@WebInitParam(name="name",value = "Geek"),@WebInitParam(name="city",value = "Indore")})
public class ServletConfigDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	ServletConfig config=getServletConfig();
	PrintWriter pw=response.getWriter();
	response.setContentType("text/html");
	/*
	Enumeration<String> en=config.getInitParameterNames();
	while(en.hasMoreElements())
	{
		
		 
		  String name=en.nextElement();
		System.out.println(name+" "+config.getInitParameter(name));
		
		
		
	}*/
//	Iterator<String> en=config.getInitParameterNames().asIterator();
	Iterator<String> en=config.getInitParameterNames().asIterator();
	pw.println("<h2>Servlet Config Name and Values</h2>");
	while(en.hasNext())
	{
		String name=en.next();
		pw.println(name+" "+config.getInitParameter(name));
	}
	
	ServletContext context=getServletContext();
	Enumeration<String> en1=context.getInitParameterNames();
	pw.println("<h2>Servlet Context Name and Values</h2>");
	while(en1.hasMoreElements())
	{
		String name=en1.nextElement();
		pw.println(name+" "+context.getInitParameter(name));
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
