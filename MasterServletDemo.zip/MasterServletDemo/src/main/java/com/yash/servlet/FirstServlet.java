package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
//@WebServlet("/FirstServlet")
@WebServlet("/hello") //Means this url is mapped with below servlet
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");	
		PrintWriter pw=response.getWriter();
		
		for(int i=1;i<=10;i++)
		{
			int r = (int) Math.round(Math.random() * 255);
		int g = (int) Math.round(Math.random() * 255);
		
		int b = (int) Math.round(Math.random() * 255);
			pw.write("<h2 style='color:rgb("+r+","+g+","+b+")'>Hello master developer</h2>");
			
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
