package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.dao.EmployeeDAO;
import com.yash.model.User1;

@WebServlet("/EmployeeAddServlet")
public class EmployeeAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		
		String name=request.getParameter("name");
		int eid=Integer.parseInt(request.getParameter("eid"));
		String designation=request.getParameter("designation");
		int salary=Integer.parseInt(request.getParameter("salary"));
		String email=request.getParameter("email");
		//ublic User1(int eid, String ename, String designation, int salary, String email) 
		User1 u=new User1(eid,name,designation,salary,email);
		EmployeeDAO d=new EmployeeDAO();
		d.addEmployee(u);
		pw.println("User Added");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
