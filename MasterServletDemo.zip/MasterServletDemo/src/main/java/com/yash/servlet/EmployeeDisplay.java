package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yash.model.*;
import com.yash.dao.EmployeeDAO;
import java.util.*;

@WebServlet("/EmployeeDisplay")
public class EmployeeDisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		try
		{
			EmployeeDAO d=new EmployeeDAO();
		List<User1> employees=d.getAllEmployees();
		
		
		pw.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC' crossorigin='anonymous'>");
		pw.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js' integrity='sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM' crossorigin='anonymous'></script>");
		pw.println("<table class='table'>");
		pw.println("<thead>");
		pw.println("<th scope='col'>E.Id.</th>");
		pw.println("<th scope='col'>Name</th>");
		pw.println("<th scope='col'>Designation</th>");
		pw.println("</thead>");
		for(User1 employee:employees)
		{
			pw.println("<tr scope='row'>");
			pw.println("<td>"+employee.getEid()+"</td><td>"+employee.getEname()+"</td><td>"+employee.getDesignation()+"</td>");
			pw.println("</tr>");
		}
		pw.println("<table>");
		
		
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
