package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.dao.DepartmentDAOImpl;
import com.yash.model.Department;

/**
 * Servlet implementation class DepartmentDisplay
 */
@WebServlet("/DepartmentDisplay")
public class DepartmentDisplay extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		DepartmentDAOImpl d=new DepartmentDAOImpl();
		List<Department> departments=d.getAllDepartment();
		pw.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">");
		pw.println("<select class='form-select' id='inputGroupSelect02' name='city'>");
	    pw.println("<option selected>Choose...</option>");
	    for(Department dept:departments)
	    {
	    //departments.stream().forEach(department->{pw.println("<option>"+department.getDeptName()+"</option>");});
	    //onchange='form.submit'	
	    pw.println("<option value='"+dept.getDeptName()+"' >"+dept.getDeptName()+"</option>");
	    }
	    
	  pw.println("</select>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
