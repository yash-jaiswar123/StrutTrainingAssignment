package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.dao.DepartmentDAOImpl;
import com.yash.dao.EmployeeDAO;
import com.yash.model.*;

@WebServlet("/GetByDepartment")
public class GetByDepartment extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public static String getEmployeeRow(User1 e1) {
		return "<tr><td>" + e1.getEname() + "</td><td>" + e1.getEid() + "</td><td>" + e1.getSalary() + "</td></tr>";
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		try {
			List<Department> departments = new DepartmentDAOImpl().getAllDepartment();
			String dname = request.getParameter("s1") == null ? "sales" : request.getParameter("s1");
			pw.write("<form>");
			pw.write("<select name='s1'   onchange='form.submit()'>");
			departments.stream().forEach(department -> {
				if (department.getDeptName().equals(dname))
					pw.write("<option selected>" + department.getDeptName() + "</option>");
				else
					pw.write("<option>" + department.getDeptName() + "</option>");
			});

			pw.write("</select>");
			pw.write("</form>");

//	            List<User1> getByDepartment(String department)
			EmployeeDAO d = new EmployeeDAO();
			List<User1> employees = d.getByDepartment(dname);
			pw.write("<table>");
			employees.stream().forEach(employee -> {
				pw.write(GetByDepartment.getEmployeeRow(employee));
			});
			pw.write("</table>");

		} catch (Exception e) {
			System.out.print(e);
		}

	}

	/*
	 * Below is my approach protected void doGet(HttpServletRequest request,
	 * HttpServletResponse response) throws ServletException, IOException {
	 * PrintWriter pw=response.getWriter();
	 * 
	 * try { String department=request.getParameter("designation");
	 * response.setContentType("text/html"); System.out.println(department);
	 * if(department!=null) {
	 * 
	 * pw.println("<form action='GetByDepartment' method='post'>");
	 * pw.println("Designation <input type='text' name='designation'></input>");
	 * pw.println("<button type='submit'>Get Employee</button>");
	 * pw.println("</form>");
	 * 
	 * pw.println("<table border='1 px solid black'>");
	 * pw.println("<thead><th>Eid</th><th>Employee Name</th><th>Salary</th></thead>"
	 * ); pw.println("<tbody>"); EmployeeDAO d=new EmployeeDAO(); List<User1>
	 * employees=d.getByDepartment(department); if(employees.size()==0) {
	 * pw.println("No employee present for particular department"); return; }
	 * for(User1 employee:employees) { pw.println("<tr>");
	 * pw.println("<td>"+employee.getEid()+"</td><td>"+employee.getEname()+
	 * "</td><td>"+employee.getSalary()+"</td>"); pw.println("</tr>"); }
	 * pw.println("</tbody>"); pw.println("</table>"); } else {
	 * System.out.println("department");
	 * pw.println("<form action='GetByDepartment' method='post'>");
	 * pw.println("Designation <input type='text' name='designation'></input>");
	 * pw.println("<button type='submit'>Get Employee</button>");
	 * pw.println("</form>"); }
	 * 
	 * 
	 * }catch(Exception e) { System.out.println(e); } }
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
