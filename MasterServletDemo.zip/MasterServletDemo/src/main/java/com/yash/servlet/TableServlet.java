package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TableServlet
 */
@WebServlet("/TableServlet")
public class TableServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		int num=0;
		if(request.getParameter("num")==null)
		{
			pw.print("No number given");
			return;
		}
		num=Integer.parseInt(request.getParameter("num"));
		/*for(int i=1;i<=10;i++)
		{
			pw.print(num+"*"+i+"="+num*i+"<br>");
		}*/
		pw.print("<table border='1'>");
		for(int i=1;i<=10;i++)
		{
			String color=i%2==0?"White":"Grey";
			pw.print("<tr style='background-color:"+color+"'>");
			pw.print("<td>"+num+"</td>");
			pw.print("<td>*</td>");
			pw.print("<td>"+i+"</td>");
			pw.print("<td>=</td>");
			pw.print("<td>"+num*i+"</td>");
		}
		pw.print("<table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
