package org.yash.tech;

public class TutorialAction {

	private String name;
	private String language;
	
	
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String execute()
	{
		System.out.println("Hello from execute");
		System.out.println(language);
		setName("Yash Tech");
		return "success";
	}
	
}
