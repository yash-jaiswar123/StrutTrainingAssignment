package com.yash.technology;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcAppApplication.class, args);
	}

}
