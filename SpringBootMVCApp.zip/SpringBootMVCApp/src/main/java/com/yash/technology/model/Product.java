package com.yash.technology.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
    @Column(name="product_id")
    private String productId;
    
    @Column(name="category")
    private String category;
    
    @Column(name="description")
    private String description;
    
    @Column(name="name")
    private String name;
    
    @Column(name="manufacturer")
    private String manufacturer;
    
    @Column(name="unit_price")
    private int unitPrice;
    
    public Product() {}
	
}
