package com.yash.technology.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yash.technology.model.Product;

@Controller
@RequestMapping("/product")
public class ProductController {

	@RequestMapping(method=RequestMethod.GET,value="/all")
	public String getAllProducts()
	{
		List<Product> products;
		
	}
	
}
