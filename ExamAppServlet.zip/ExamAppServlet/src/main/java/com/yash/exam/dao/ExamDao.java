package com.yash.exam.dao;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.yash.exam.model.Question;

public class ExamDao {

	public static List<Question> createQuestions()
	{
		List<Question>lst=new LinkedList<>();
		Question q=new Question();
		q.setQuestion("Which of the Following is completely OOP language?");
		q.setAnswer("SmallTalk");
		q.setId("1");
		q.setOptions(Arrays.asList("C","Java","Python","SmallTalk"));
		Question q2=new Question();
		q2.setQuestion("Which of the following is not the OOP concept?");
		q2.setAnswer("Constructor");
		q2.setId("2");
		q2.setOptions(Arrays.asList("Inheritance","Polymorphism","Constructor","Abstraction"));
		
		Question q3=new Question();
		q3.setQuestion("Whcih of the following is interpreted language?");
		q3.setAnswer("Python");
		q3.setId("3");
		q3.setOptions(Arrays.asList("C","Java","Python","HTML"));

		
		Question q4=new Question();
		q4.setQuestion("Which of the following language is both compiled and interpreted?");
		q4.setAnswer("Java");
		q4.setId("4");
		q4.setOptions(Arrays.asList("C","Java","Python","SmallTalk"));

		
		Question q5=new Question();
		q5.setQuestion("Which of the following highly machine interactive language?");
		q5.setAnswer("C");
		q5.setId("5");
		q5.setOptions(Arrays.asList("C","Java","Python","SmallTalk"));

		
		Question q6=new Question();
		q6.setQuestion("Automatic type conversion is possible in which of the possible cases?");
		q6.setId("6");
		q6.setAnswer("int to long");
		q6.setOptions(Arrays.asList("byte to int","int to long","long to int","short to int"));
		
		Question q7=new Question();
		q7.setQuestion("Select the valid statement");
		q7.setId("7");
		q7.setAnswer("char[] ch = new char[5]");
		q7.setOptions(Arrays.asList("char[] ch=new char(5)","char[] ch = new char[5]","char[]ch=new char()","char[]ch=new char[]"));
	
		Question q8=new Question();
		q8.setQuestion("When an array is passed to a method, what does the method receive?");
		q8.setAnswer("The reference of Array");
		q8.setId("8");
		q8.setOptions(Arrays.asList("The reference of Array","A copy of the array","Length of the array","Copy of first element"));

		Question q9=new Question();
		q9.setQuestion("Arrays in java are-");
		q9.setAnswer("object");
		q9.setId("9");
		q9.setOptions(Arrays.asList("Object references","object","Primitive data type","None"));
		
		Question q10=new Question();
		q10.setQuestion("When is the object created with new keyword?");
		q10.setAnswer("At run time");
		q10.setId("10");
		q10.setOptions(Arrays.asList("At run time","At compile time","Depends on the code","None"));
		lst.add(q);
		lst.add(q2);
		lst.add(q3);
		lst.add(q4);
		lst.add(q5);
		lst.add(q6);
		lst.add(q7);
		lst.add(q8);
		lst.add(q9);
		lst.add(q10);
		return lst;
	}
	
}
