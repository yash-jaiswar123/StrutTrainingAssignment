package com.yash.exam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.exam.model.Question;

/**
 * Servlet implementation class NextServlet
 */
@WebServlet("/NextServlet")
public class NextServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String answer=request.getParameter("n1");
		HttpSession session=request.getSession();
		int num=(Integer)session.getAttribute("number");
		if(num==10)
		{
			request.getRequestDispatcher("FinalServlet").forward(request, response);
			return;
		}
		
		List<Question>lst=(List<Question>) session.getAttribute("QuestionList");
		lst.get(num-1).setUserAnswer(answer);
		System.out.println(lst.get(num-1));
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		pw.println("<h1 align='center'>MCQ Questions</h1>");
		Question q=lst.get(num);
		session.setAttribute("number", num+1);
		pw.println("<form action='NextServlet'>");
		pw.println("<h3>"+q.getId()+"). "+q.getQuestion()+"</h3>");
		//pw.println("<input type='radio' name='"+q.getId()+"'>");
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(0)+"'>"+q.getOptions().get(0));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(1)+"'>"+q.getOptions().get(1));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(2)+"'>"+q.getOptions().get(2));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(3)+"'>"+q.getOptions().get(3));
		pw.println("<button type='submit'>Next</button>");
		pw.println("</form>");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
