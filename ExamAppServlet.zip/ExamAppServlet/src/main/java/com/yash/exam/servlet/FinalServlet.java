package com.yash.exam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.exam.model.Question;

/**
 * Servlet implementation class FinalServlet
 */
@WebServlet("/FinalServlet")
public class FinalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String answer=request.getParameter("n1");
		HttpSession session=request.getSession();
		List<Question>lst=(List<Question>) session.getAttribute("QuestionList");
		lst.get(9).setUserAnswer(answer);
		System.out.println(lst.get(9));
		int count=0;
		for(Question q:lst)
		{
			if(q.getAnswer().equals(q.getUserAnswer()))
			{
				count++;
			}
			else
			{
				System.out.println(q.getAnswer()+" "+q.getUserAnswer());
			}
		}
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		String name=(String) session.getAttribute("username");
		pw.println("<h1>"+name+" Your total score out of 10 is "+count+"</h1>");
		session.invalidate();
		System.out.println(request.getSession(false));
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
