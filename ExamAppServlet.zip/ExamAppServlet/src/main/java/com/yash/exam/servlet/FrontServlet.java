package com.yash.exam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.exam.dao.ExamDao;
import com.yash.exam.model.Question;

/**
 * Servlet implementation class FrontServlet
 */
@WebServlet("/FrontServlet")
public class FrontServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		try
		{
		String username=request.getParameter("username");
		HttpSession session=request.getSession();
		session.setAttribute("username",username);
		
		pw.println("<h1>Welcome to exam page</h1>");
		pw.println("<p>You have total 10 Questions to solve</p>");
		List<Question> lst=ExamDao.createQuestions();
		System.out.println("Checkckckckkc"+lst);
		session.setAttribute("QuestionList", lst);
		session.setAttribute("number", 1);
		System.out.println("0-------------------------------");
		System.out.println("");
		pw.print("<h3>Please click <a href='QuestionServlet'>here</a> to move to the questions page</h3>");
		}catch(Exception e)
		{
		pw.println("<h1 style='color:red'>Some error occur</h1>");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
