package com.yash.exam.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import com.yash.exam.model.*;
/**
 * Servlet implementation class QuestionServlet
 */
@WebServlet("/QuestionServlet")
public class QuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		int num=(Integer)session.getAttribute("number");
		if(num==10)
		{
			request.getRequestDispatcher("FinishServlet").forward(request, response);
		}
		List<Question>lst=(List<Question>) session.getAttribute("QuestionList");
		System.out.println(lst);
		System.out.println(num);
		
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		pw.println("<h1 align='center'>MCQ Questions</h1>");
		Question q=lst.get(num-1);
		
		pw.println("<form action='NextServlet'>");
		pw.println("<h3>"+q.getId()+"). "+q.getQuestion()+"</h3>");
		//pw.println("<input type='radio' name='"+q.getId()+"'>");
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(0)+"'>"+q.getOptions().get(0));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(1)+"'>"+q.getOptions().get(1));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(2)+"'>"+q.getOptions().get(2));
		pw.println("<input type='radio' name='n1' value='"+q.getOptions().get(3)+"'>"+q.getOptions().get(3));
		pw.println("<button type='submit'>Next</button>");
		pw.println("</form>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
