package com.yash.technology.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.technology.dao.LoginRegisterDao;
import com.yash.technology.model.User;

public class LoginAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		User u=(User)form;
		System.out.println(u.getUsername());
		System.out.print(u.getPassword());
		
		User user=new LoginRegisterDao().getByUsername(u.getUsername());
		if(user==null)
		{
			return mapping.findForward("error");
		}
		
		if(!u.getPassword().equals(user.getPassword()))
		{
			return mapping.findForward("error");
		}
		
		return mapping.findForward("success");
	}

	
	
}
