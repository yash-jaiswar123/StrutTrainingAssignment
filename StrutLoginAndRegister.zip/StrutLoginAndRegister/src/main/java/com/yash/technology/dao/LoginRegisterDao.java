package com.yash.technology.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.yash.technology.model.User;

public class LoginRegisterDao {

	public void addUser(User u)
	{
		try
		{
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("insert into user values(?,?)");
			ps.setString(1, u.getUsername());
			ps.setString(2, u.getPassword());
			ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public User getByUsername(String username)
	{
	
		User u=null;
		try
		{
			Connection c=DAOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select * from user where username=?");
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				u=new User();
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
			}
			ps.executeQuery();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return u;
		
	}
	
}
