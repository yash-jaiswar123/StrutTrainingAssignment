package com.yash.technology.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAOConnection {

	public static Connection getConnection()
	{
		Connection c=null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			c=DriverManager.getConnection("jdbc:mysql://localhost:3306/springdata","root","root");
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return c;
	}
	
}
